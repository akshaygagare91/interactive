const radios = document.querySelectorAll('input[name="bundle"]');
const totalPrice = document.getElementById("total-price");


radios.forEach(radio => {
  radio.addEventListener("change", () => {
    
    document.querySelectorAll(".expandable-content").forEach(c => {
      c.style.maxHeight = "0px";
      c.style.opacity = "0";
      c.style.padding = "0";
    });

  
    const expandable = radio.closest(".option").querySelector(".expandable-content");
    if (expandable) {
      expandable.style.maxHeight = expandable.scrollHeight + "px";
      expandable.style.opacity = "1";
      expandable.style.padding = "10px 0";
    }

  
    totalPrice.textContent = "DKK " + parseFloat(radio.value).toFixed(2);
  });
});


if (radios[1]) {
  radios[1].checked = true;
  radios[1].dispatchEvent(new Event("change"));
}

